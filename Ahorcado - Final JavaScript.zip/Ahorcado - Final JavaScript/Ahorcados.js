String.prototype.replaceAt=function(index, character) { return this.substring(0, index) + character + this.substring(index+character.length); } 

var palabras = ["carpintero", 
"edificio", 
"helicoptero", 
"panda", 
"kinal", 
"colina", 
"guatemala", 
"murcielago", 
"automovil",
"barco",
"casa",
"programador",
"microfono",
"detective",
"europa",];

var palabra = palabras[Math.floor(Math.random()*palabras.length)];
var guion = palabra.replace(/./g, "_ ")
document.getElementById('palabra').innerHTML = guion;
let cont = 1;
var ingresos = [];


function comprobar(){
  var letra = document.querySelector('#letra').value;
  let fallo = true;
  

  if(ingresos.includes(letra)){
  }else{
    ingresos.push(letra);
    for(var i in palabra){
      if(letra == palabra[i]){
        guion = guion.replaceAt(i*2, letra);
        fallo = false;
      }
    }
  
  if(fallo){
    cont++;
    const source = `img/imagen ${cont}.jpg`;
    imagen.src = source
    if(cont ==7){
      var button = document.getElementById('btn');
      var input = document.getElementById('letra');
      document.getElementById('acierto').innerHTML = "¡Perdiste!";
      document.getElementById('btn2').innerHTML = "Jugar otra vez";
      document.getElementById('palabracorrecta').innerHTML= "La palabra correcta era: " + palabra;
      button.disabled = true;
      input.disabled = true;
    }
  }else{
    if(guion.indexOf('_') <0){
      var button = document.getElementById('btn');
      var input = document.getElementById('letra');
      document.getElementById('acierto').innerHTML = "¡Aceraste!";
      document.getElementById('btn2').innerHTML = "Jugar otra vez";
      button.disabled = true;
      input.disabled = true;
    }
  }
}
  document.getElementById('palabra').innerHTML = guion;
  document.querySelector('#letra').value = '';
  document.querySelector('#letra').focus();
};

function recargar(){
  window.location.reload();
}


